INSERT INTO goat.notice_event (notice_event_num, reg, content, read_count, title, type, account_num) VALUES (1, '2024-10-07', '123', 2, '123', 2, null);
